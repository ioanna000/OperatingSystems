#include <stdio.h>
#include <stdlib.h>
#include <openssl/sha.h>

typedef unsigned char byte;

typedef struct Block_mtdt {
        unsigned char hash[20];
        unsigned short references;
        unsigned short offset;
} block_mtdt;


int main(int argc, char *argv[]) {
    const int DataLen = 30;
    //SHA_CTX shactx;
    //byte digest[SHA_DIGEST_LENGTH];
    int i;

    byte* testdata = (byte *)malloc(DataLen);
    for (i=0; i<DataLen; i++) testdata[i] = 'a' + i;

    /*SHA1_Init(&shactx);
    SHA1_Update(&shactx, testdata, DataLen);
    SHA1_Final(digest, &shactx);*/

	unsigned char * returned = SHA1(testdata, DataLen, NULL);
	unsigned char * returned1 = (unsigned char *) malloc(20*sizeof(unsigned char));
	SHA1(testdata, DataLen, returned1);
	printf("%d\n", SHA_DIGEST_LENGTH);
	printf("size of struct = %d\n", sizeof(block_mtdt));
	printf("size of offset = %ld\n", sizeof(off_t));
    for (i=0; i<SHA_DIGEST_LENGTH; i++)
	printf("%x ", returned[i]);
    putchar('\n');

	for(i = 0; i < SHA_DIGEST_LENGTH; i++) {
		printf("%x ", returned1[i]);
	}
	putchar('\n');

    return 0;
}
