#include "roots.h"

int main(int argc, char *argv[]) {
	find_roots_wrapper();

	return(0);
}
