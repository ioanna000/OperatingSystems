int find_roots_wrapper(void);
