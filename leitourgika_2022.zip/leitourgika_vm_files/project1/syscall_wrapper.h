#ifndef _SYSCALL_WRAPPER_H
#define _SYSCALL_WRAPPER_H

int hello_syscall_wrapper(void);

#endif
