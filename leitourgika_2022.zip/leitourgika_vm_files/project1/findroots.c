#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/sched.h>

SYSCALL_DEFINE0 (find_roots) {
        int id = 1;
        struct task_struct *curr = get_current();

        printk("find_roots sysstem call called by process %d\n", curr->pid);

        

        do{
		id = curr->pid;
                printk("id: %d, name: %s \n", id, curr->comm);
                curr = curr->parent;
        }while(id != 1);




        return(0);
}
