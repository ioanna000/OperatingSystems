#include "syscall_wrapper.h"

int main(int argc, char *argv[]) {
	hello_syscall_wrapper();

	return 0;
}
