#!/bin/sh
../src/bbfs rootdir/ mountdir/
ls
cp test.txt mountdir/
ls -l rootdir/
ls -l rootdir/storage/
ls -l mountdir/
fusermount -u mountdir
rm rootdir/test* rootdir/storage/block_file rootdir/storage/metadata_file
