#!/bin/sh
fusermount -u mountdir
rm rootdir/test0 rootdir/storage/block_file rootdir/storage/metadata_file
cd ..
make
cd example
../src/bbfs rootdir/ mountdir/
dd if=/dev/urandom of=mountdir/test0 bs=4096 count=1
