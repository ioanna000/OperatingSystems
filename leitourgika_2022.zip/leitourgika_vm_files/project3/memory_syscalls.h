
long our_kmalloc(size_t size);
long our_kfree(void * ptr);
long our_slob_get_total_alloc_mem();
long our_slob_get_total_free_mem();
