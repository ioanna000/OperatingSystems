#!/bin/bash
cd /usr/src/linux-5.4.86-dev/
sudo mv ~/slob.c mm/
sudo make -j3
sudo make modules_install
sudo make install
